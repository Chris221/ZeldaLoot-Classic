-- Global Text Variables
ZL_SET_ALTTP            = "ALTTP: A Link to the Past"
ZL_SET_OOT              = "OOT: Ocarina of Time Orchestrated"
ZL_SET_TP               = "TP: Twilight Princess"

-- General Global Variables
ZL_AddonVersion         = "|cff00ff002.2.0|r"
ZL_AddonName            = "ZeldaLoot Classic"
ZL_AddonColor           = "|cff00ffff"
ZL_soundHandle          = 0

ZL_TOOLTIP_ANCHOR       = "ANCHOR_RIGHT"